"""Audio quality features and robustness perturbations (all operate on 16 kHz mono float32)."""
from typing import Callable, Sequence

import librosa
import numpy as np
from scipy.signal import butter, fftconvolve, sosfilt

SR = 16000
Perturbation = Callable[[np.ndarray, np.random.Generator], np.ndarray]


def _dbfs(value: float) -> float:
    return float(20 * np.log10(max(float(value), 1e-12)))


def _rms(y: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(y, dtype=np.float64)) + 1e-12))


def _limit_peak(y: np.ndarray) -> np.ndarray:
    peak = float(np.max(np.abs(y))) if y.size else 0.0
    return (y / peak if peak > 1.0 else y).astype(np.float32)


def audio_features(y: np.ndarray, sr: int = SR) -> dict:
    y = np.asarray(y, dtype=np.float32)
    if y.size == 0:
        return {"duration_sec": 0.0, "rms_dbfs": -120.0, "peak_dbfs": -120.0,
                "clipping_ratio": 0.0, "silence_ratio": 1.0, "noise_floor_dbfs_proxy": -120.0}
    frame, hop = int(sr * 0.025), int(sr * 0.010)
    rms = _rms(y)
    frames = librosa.util.frame(y, frame_length=frame, hop_length=hop) if len(y) >= frame else y.reshape(-1, 1)
    frame_rms = np.sqrt(np.mean(np.square(frames, dtype=np.float64), axis=0))
    quiet = frame_rms[frame_rms <= np.percentile(frame_rms, 20)]
    return {
        "duration_sec": len(y) / sr,
        "rms_dbfs": _dbfs(rms),
        "peak_dbfs": _dbfs(np.max(np.abs(y))),
        "clipping_ratio": float(np.mean(np.abs(y) >= 0.999)),
        "silence_ratio": float(np.mean(frame_rms < max(1e-4, rms * 0.03))),
        "noise_floor_dbfs_proxy": _dbfs(np.median(quiet)),  # relative proxy, not a calibrated SNR
    }


def _add_noise_at_snr(y: np.ndarray, noise: np.ndarray, snr_db: float) -> np.ndarray:
    scale = _rms(y) / (10 ** (snr_db / 20)) / _rms(noise)
    return _limit_peak(y + noise * scale)


def white_noise(snr_db: float) -> Perturbation:
    return lambda y, rng: _add_noise_at_snr(y, rng.normal(size=y.shape).astype(np.float32), snr_db)


def real_noise(bank: Sequence[np.ndarray], snr_db: float) -> Perturbation:
    """Mix a random crop of a real noise recording (street, cafe, ...) at the target SNR."""
    def apply(y, rng):
        noise = bank[int(rng.integers(len(bank)))]
        if len(noise) < len(y):
            noise = np.tile(noise, int(np.ceil(len(y) / len(noise))))
        start = int(rng.integers(0, len(noise) - len(y) + 1))
        return _add_noise_at_snr(y, noise[start:start + len(y)], snr_db)
    return apply


def telephone() -> Perturbation:
    """Narrowband telephony: 300-3400 Hz band, 8 kHz sampling, 8-bit mu-law quantization."""
    sos = butter(4, [300, 3400], btype="bandpass", fs=SR, output="sos")
    mu = 255.0

    def apply(y, rng):
        y = sosfilt(sos, y).astype(np.float32)
        y = librosa.resample(y, orig_sr=SR, target_sr=8000)
        y = np.clip(y, -1.0, 1.0)
        companded = np.sign(y) * np.log1p(mu * np.abs(y)) / np.log1p(mu)
        companded = np.round(companded * 127) / 127
        y = np.sign(companded) * np.expm1(np.abs(companded) * np.log1p(mu)) / mu
        return librosa.resample(y.astype(np.float32), orig_sr=8000, target_sr=SR).astype(np.float32)
    return apply


def speed(rate: float) -> Perturbation:
    return lambda y, rng: librosa.effects.time_stretch(y, rate=rate).astype(np.float32)


def gain(db: float) -> Perturbation:
    return lambda y, rng: _limit_peak(y * 10 ** (db / 20))


def reverb(rt60: float = 0.5) -> Perturbation:
    """Synthetic room: exponentially decaying noise impulse response."""
    def apply(y, rng):
        n = int(SR * rt60)
        t = np.arange(n) / SR
        ir = rng.normal(size=n) * np.exp(-6.9 * t / rt60)
        ir /= np.linalg.norm(ir)
        wet = fftconvolve(y, ir.astype(np.float32))[: len(y)]
        return _limit_peak(wet * (_rms(y) / _rms(wet)))
    return apply


def build_conditions(noise_bank: Sequence[np.ndarray] = ()) -> dict:
    conditions = {
        "clean": None,
        "white_20dB": white_noise(20),
        "white_10dB": white_noise(10),
        "white_5dB": white_noise(5),
        "telephone": telephone(),
        "speed_0.85": speed(0.85),
        "speed_1.15": speed(1.15),
        "low_volume_-25dB": gain(-25),
        "reverb_0.5s": reverb(0.5),
    }
    if len(noise_bank):
        for snr in (20, 10, 5):
            conditions[f"real_noise_{snr}dB"] = real_noise(noise_bank, snr)
    return conditions
