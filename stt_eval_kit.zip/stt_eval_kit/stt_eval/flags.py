"""Heuristic detectors for typical ASR failure modes (hallucination, loops, wrong language)."""
import re

_ARABIC_LETTER = re.compile(r"[ء-ي]")
_ANY_LETTER = re.compile(r"[^\W\d_]")


def max_repeat(tokens: list, max_ngram: int = 4) -> int:
    """Largest number of consecutive repetitions of any 1..max_ngram word sequence."""
    best = 1 if tokens else 0
    for n in range(1, max_ngram + 1):
        for i in range(len(tokens) - n + 1):
            gram, reps, j = tokens[i:i + n], 1, i + n
            while tokens[j:j + n] == gram:
                reps += 1
                j += n
            best = max(best, reps)
    return best


def non_arabic_ratio(text: str) -> float:
    letters = _ANY_LETTER.findall(text)
    if not letters:
        return 0.0
    return 1 - len(_ARABIC_LETTER.findall(text)) / len(letters)


def failure_flags(ref: str, hyp: str, *, length_ratio_max: float = 2.0, repeat_min: int = 3,
                  foreign_max: float = 0.3) -> dict:
    ref_len, hyp_words = len(ref.split()), hyp.split()
    ratio = len(hyp_words) / ref_len if ref_len else float("inf")
    return {
        "flag_empty": not hyp.strip(),
        "flag_too_long": ratio > length_ratio_max,
        "flag_repetition": max_repeat(hyp_words) >= repeat_min and max_repeat(ref.split()) < repeat_min,
        "flag_foreign_script": non_arabic_ratio(hyp) > foreign_max and non_arabic_ratio(ref) <= foreign_max,
    }
