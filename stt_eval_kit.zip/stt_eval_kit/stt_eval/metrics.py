"""Error-rate computation with S/D/I breakdown, bootstrap confidence intervals and confusion mining."""
from collections import Counter

import jiwer
import numpy as np
import pandas as pd


def utterance_stats(ref: str, hyp: str) -> dict:
    w = jiwer.process_words(ref, hyp)
    c = jiwer.process_characters(ref, hyp)
    return {
        "w_sub": w.substitutions, "w_del": w.deletions, "w_ins": w.insertions, "w_hit": w.hits,
        "c_sub": c.substitutions, "c_del": c.deletions, "c_ins": c.insertions, "c_hit": c.hits,
    }


def score_utterances(refs, hyps) -> pd.DataFrame:
    """One row per utterance. Rows whose reference is empty are dropped (WER is undefined)."""
    rows = [{"ref": r, "hyp": h, **utterance_stats(r, h)} for r, h in zip(refs, hyps) if r]
    df = pd.DataFrame(rows)
    df["w_err"] = df.w_sub + df.w_del + df.w_ins
    df["w_ref_len"] = df.w_sub + df.w_del + df.w_hit
    df["c_err"] = df.c_sub + df.c_del + df.c_ins
    df["c_ref_len"] = df.c_sub + df.c_del + df.c_hit
    df["wer"] = df.w_err / df.w_ref_len
    df["cer"] = df.c_err / df.c_ref_len
    return df


def corpus_rate(df: pd.DataFrame, unit: str = "w") -> float:
    return float(df[f"{unit}_err"].sum() / df[f"{unit}_ref_len"].sum())


def bootstrap_ci(df: pd.DataFrame, unit: str = "w", n_boot: int = 1000, seed: int = 42, alpha: float = 0.05):
    """Percentile CI obtained by resampling whole utterances."""
    err, length = df[f"{unit}_err"].to_numpy(), df[f"{unit}_ref_len"].to_numpy()
    idx = np.random.default_rng(seed).integers(0, len(df), size=(n_boot, len(df)))
    rates = err[idx].sum(axis=1) / length[idx].sum(axis=1)
    lo, hi = np.percentile(rates, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(lo), float(hi)


def summarize(df: pd.DataFrame, n_boot: int = 1000, seed: int = 42) -> dict:
    ref_words = df.w_ref_len.sum()
    lo, hi = bootstrap_ci(df, "w", n_boot, seed)
    return {
        "n_scored": len(df),
        "wer": corpus_rate(df, "w"), "wer_ci_low": lo, "wer_ci_high": hi,
        "cer": corpus_rate(df, "c"),
        "sub_rate": df.w_sub.sum() / ref_words,
        "del_rate": df.w_del.sum() / ref_words,
        "ins_rate": df.w_ins.sum() / ref_words,
    }


def top_confusions(refs, hyps, k: int = 25) -> pd.DataFrame:
    """Most frequent word-level substitutions, deletions and insertions."""
    counts = Counter()
    for ref, hyp in zip(refs, hyps):
        if not ref:
            continue
        out = jiwer.process_words(ref, hyp)
        r, h = ref.split(), hyp.split()
        for chunk in out.alignments[0]:
            rs, re_, hs, he = chunk.ref_start_idx, chunk.ref_end_idx, chunk.hyp_start_idx, chunk.hyp_end_idx
            if chunk.type == "substitute":
                counts.update(("sub", a, b) for a, b in zip(r[rs:re_], h[hs:he]))
            elif chunk.type == "delete":
                counts.update(("del", a, "") for a in r[rs:re_])
            elif chunk.type == "insert":
                counts.update(("ins", "", b) for b in h[hs:he])
    rows = [{"type": t, "reference": a, "prediction": b, "count": n} for (t, a, b), n in counts.most_common(k)]
    return pd.DataFrame(rows, columns=["type", "reference", "prediction", "count"])
