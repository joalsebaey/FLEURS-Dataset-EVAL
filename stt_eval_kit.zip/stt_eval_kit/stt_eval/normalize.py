"""Arabic text normalization applied identically to references and predictions."""
import re
from dataclasses import asdict, dataclass

_DIACRITICS = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭ]")
_TATWEEL = "ـ"
_ALEF_FORMS = re.compile("[إأآٱ]")
_NON_WORD = re.compile(r"[^\w\s]")
_SPACES = re.compile(r"\s+")
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


@dataclass(frozen=True)
class NormConfig:
    remove_diacritics: bool = True
    unify_alef: bool = True
    unify_ya: bool = True
    unify_ta_marbuta: bool = True
    unify_hamza_seat: bool = False
    map_digits: bool = True
    lowercase_latin: bool = True

    def describe(self) -> dict:
        return asdict(self)


def normalize_arabic(text, cfg: NormConfig = NormConfig()) -> str:
    text = str(text or "").strip()
    if cfg.remove_diacritics:
        text = _DIACRITICS.sub("", text)
    text = text.replace(_TATWEEL, "")
    if cfg.unify_alef:
        text = _ALEF_FORMS.sub("ا", text)
    if cfg.unify_ya:
        text = text.replace("ى", "ي")
    if cfg.unify_ta_marbuta:
        text = text.replace("ة", "ه")
    if cfg.unify_hamza_seat:
        text = text.replace("ؤ", "و").replace("ئ", "ي")
    if cfg.map_digits:
        text = text.translate(_DIGITS)
    if cfg.lowercase_latin:
        text = text.lower()
    # \w excludes Arabic punctuation (، ؛ ؟), so this strips it as well.
    text = _NON_WORD.sub(" ", text)
    return _SPACES.sub(" ", text).strip()
