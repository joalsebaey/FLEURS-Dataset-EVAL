"""Dataset loading, Whisper inference and the evaluation loop."""
import time
from pathlib import Path

import librosa
import numpy as np
import pandas as pd
from tqdm.auto import tqdm

from .audio import SR, audio_features
from .flags import failure_flags
from .metrics import score_utterances, summarize
from .normalize import NormConfig, normalize_arabic


def load_fleurs(config: str, split: str, max_samples, seed: int):
    from datasets import Audio, load_dataset

    ds = load_dataset("google/fleurs", config, split=split)
    if max_samples:
        ds = ds.shuffle(seed=seed).select(range(min(max_samples, len(ds))))
    ds = ds.cast_column("audio", Audio(sampling_rate=SR))
    gender_names = ds.features["gender"].names if hasattr(ds.features["gender"], "names") else None
    items = []
    for i, row in enumerate(ds):
        y = np.asarray(row["audio"]["array"], dtype=np.float32)
        if y.ndim == 2:
            y = y.mean(axis=0 if y.shape[0] <= 8 else 1)
        gender = gender_names[row["gender"]] if gender_names else row["gender"]
        items.append({"row_index": i, "id": row["id"], "gender": gender,
                      "reference_raw": row["transcription"], "audio": y})
    return items


def load_noise_bank(noise_dir) -> list:
    if not noise_dir:
        return []
    files = [p for p in Path(noise_dir).rglob("*") if p.suffix.lower() in {".wav", ".flac", ".mp3", ".ogg"}]
    return [librosa.load(p, sr=SR, mono=True)[0] for p in files]


def build_asr(model_id: str, device: int):
    from transformers import pipeline

    return pipeline("automatic-speech-recognition", model=model_id, device=device, chunk_length_s=30)


def transcribe(asr, arrays, batch_size: int, language):
    kwargs = {"task": "transcribe", **({"language": language} if language else {})}
    outputs = asr([{"raw": a, "sampling_rate": SR} for a in arrays], batch_size=batch_size, generate_kwargs=kwargs)
    return [o["text"].strip() for o in outputs]


def evaluate_condition(items, transcribe_fn, perturb, rng, norm_cfg: NormConfig, batch_size: int):
    """Returns per-utterance dataframe and real-time factor (processing time / audio duration)."""
    hyps_raw, audio_seconds, elapsed = [], 0.0, 0.0
    for start in range(0, len(items), batch_size):
        batch = items[start:start + batch_size]
        arrays = [it["audio"] if perturb is None else perturb(it["audio"], rng) for it in batch]
        audio_seconds += sum(len(a) for a in arrays) / SR
        t0 = time.perf_counter()
        hyps_raw.extend(transcribe_fn(arrays))
        elapsed += time.perf_counter() - t0

    refs = [normalize_arabic(it["reference_raw"], norm_cfg) for it in items]
    hyps = [normalize_arabic(h, norm_cfg) for h in hyps_raw]
    scored = score_utterances(refs, hyps)
    keep = [i for i, r in enumerate(refs) if r]
    meta = pd.DataFrame([{k: items[i][k] for k in ("row_index", "id", "gender", "reference_raw")} for i in keep])
    feats = pd.DataFrame([audio_features(items[i]["audio"]) for i in keep])
    flags = pd.DataFrame([failure_flags(refs[i], hyps[i]) for i in keep])
    df = pd.concat([meta, feats, scored.reset_index(drop=True), flags], axis=1)
    df["prediction_raw"] = [hyps_raw[i] for i in keep]
    return df, elapsed / audio_seconds


def run_conditions(items, transcribe_fn, conditions: dict, norm_cfg, batch_size, seed, n_boot, auto_language_fn=None):
    """Evaluate every condition; returns (summary dataframe, {condition: per-utterance dataframe})."""
    summaries, details = [], {}
    names = list(conditions) + (["clean_auto_language"] if auto_language_fn else [])
    for name in tqdm(names, desc="conditions"):
        rng = np.random.default_rng(seed)
        fn, perturb = (auto_language_fn, None) if name == "clean_auto_language" else (transcribe_fn, conditions[name])
        df, rtf = evaluate_condition(items, fn, perturb, rng, norm_cfg, batch_size)
        flag_cols = [c for c in df.columns if c.startswith("flag_")]
        summaries.append({"condition": name, **summarize(df, n_boot, seed), "rtf": rtf,
                          **{f"{c}_rate": float(df[c].mean()) for c in flag_cols},
                          "any_flag_rate": float(df[flag_cols].any(axis=1).mean())})
        details[name] = df
    summary = pd.DataFrame(summaries)
    base = summary.loc[summary.condition == "clean", "wer"]
    if len(base):
        summary["wer_delta_vs_clean"] = summary["wer"] - float(base.iloc[0])
    return summary, details
