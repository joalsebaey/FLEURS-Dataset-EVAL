import numpy as np
import pytest

from stt_eval import audio, flags, metrics
from stt_eval.normalize import NormConfig, normalize_arabic


def test_arabic_punctuation_is_stripped():
    assert normalize_arabic("مصر، القاهرة؟ نعم؛") == "مصر القاهره نعم"


def test_variants_collapse():
    assert normalize_arabic("أَحْمَد") == normalize_arabic("احمد")
    assert normalize_arabic("مدرسة") == normalize_arabic("مدرسه")
    assert normalize_arabic("على") == normalize_arabic("علي")
    assert normalize_arabic("ـــكتاب") == "كتاب"


def test_digits_are_unified():
    assert normalize_arabic("٣٠ جنيه") == normalize_arabic("30 جنيه")


def test_config_can_disable_rules():
    assert normalize_arabic("مدرسة", NormConfig(unify_ta_marbuta=False)) == "مدرسة"


def test_empty_and_none():
    assert normalize_arabic(None) == ""
    assert normalize_arabic("،؟!") == ""


def test_sdi_counts_and_rates():
    df = metrics.score_utterances(["a b c d", "x y"], ["a b c d", "x z w"])
    assert df.loc[1, ["w_sub", "w_del", "w_ins"]].tolist() == [1, 0, 1]
    assert metrics.corpus_rate(df) == pytest.approx(2 / 6)


def test_empty_references_are_dropped():
    assert len(metrics.score_utterances(["", "a b"], ["x", "a b"])) == 1


def test_bootstrap_ci_brackets_point_estimate():
    refs = [f"w{i} w{i + 1} w{i + 2}" for i in range(60)]
    hyps = [r if i % 3 else r.replace("w", "q", 1) for i, r in enumerate(refs)]
    df = metrics.score_utterances(refs, hyps)
    lo, hi = metrics.bootstrap_ci(df, n_boot=500)
    assert lo <= metrics.corpus_rate(df) <= hi and hi > lo


def test_top_confusions():
    out = metrics.top_confusions(["a b c", "a b d"], ["a x c", "a x"])
    sub = out[(out.type == "sub") & (out.reference == "b")]
    assert sub["count"].iloc[0] == 2 and sub["prediction"].iloc[0] == "x"
    assert ((out.type == "del") & (out.reference == "d")).any()


def test_failure_flags():
    assert flags.failure_flags("a b c", "")["flag_empty"]
    assert flags.failure_flags("a b", "a b a b a b a b")["flag_repetition"]
    assert flags.failure_flags("مرحبا بك", "thank you for watching")["flag_foreign_script"]
    assert flags.failure_flags("a", "a b c d e")["flag_too_long"]
    assert not any(flags.failure_flags("a b c", "a b c").values())


def test_white_noise_hits_target_snr():
    rng = np.random.default_rng(0)
    y = (0.1 * np.sin(np.linspace(0, 2000, 16000))).astype(np.float32)
    noisy = audio.white_noise(10)(y, rng)
    snr = 10 * np.log10(np.mean(y**2) / np.mean((noisy - y) ** 2))
    assert snr == pytest.approx(10, abs=0.5)


def test_perturbations_keep_shape_and_range():
    rng = np.random.default_rng(0)
    y = (0.2 * rng.normal(size=16000)).astype(np.float32)
    for fn in (audio.telephone(), audio.reverb(0.4), audio.gain(-25), audio.real_noise([y], 5)):
        out = fn(y, rng)
        assert out.shape == y.shape and np.abs(out).max() <= 1.0
    assert abs(len(audio.speed(1.15)(y, rng)) - len(y) / 1.15) < 5


def test_features_on_silence_and_empty():
    assert audio.audio_features(np.zeros(16000, np.float32))["silence_ratio"] == 1.0
    assert audio.audio_features(np.array([], np.float32))["duration_sec"] == 0.0
